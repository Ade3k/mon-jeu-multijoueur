
/*
const WebSocket = require('ws');
const mongoose = require('mongoose');
const express = require('express');
const app = express();
const PORT = 3000;

// Connexion à MongoDB
mongoose.connect('mongodb://localhost:27017/jeu-multijoueur')
  .then(() => {
    console.log('Connecté à MongoDB');
  })
  .catch((error) => {
    console.error('Erreur de connexion à MongoDB:', error);
  });

// Schéma et modèle de joueur
const playerSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  avatar: { type: String, required: true },
  score: { type: Number, default: 0 },
  playTime: { type: Number, default: 0 } // Temps de jeu en millisecondes
});

const Player = mongoose.model('Player', playerSchema);

// Stocker les joueurs actifs et le plateau du morpion
let activePlayers = {};
let morpionBoard = [['', '', ''], ['', '', ''], ['', '', '']];
let currentPlayer = null;
let movesCount = 0;

// Configurer le serveur Express pour servir les fichiers statiques (HTML, CSS, JS)
app.use(express.static('public'));

// Route pour la page d'accueil
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html'); // Chemin vers votre fichier HTML principal
});

// Créer le serveur WebSocket
const server = app.listen(PORT, () => {
  console.log(`Serveur en écoute sur le port ${PORT}`);
});

const wss = new WebSocket.Server({ server });

// Gérer la connexion des joueurs
wss.on('connection', (ws) => {
  ws.on('message', async (message) => {
    const data = JSON.parse(message);









// Attendre deux joueurs pour commencer la partie
let waitingPlayer = null; // Le joueur qui attend un autre joueur pour commencer la partie

wss.on('connection', (ws) => {
  ws.on('message', async (message) => {
    const data = JSON.parse(message);

    switch (data.type) {
      case 'join':
        const { username, avatar } = data;
        if (!username || !avatar) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme et avatar requis.' }));
          return;
        }

        let player = await Player.findOne({ username });
        if (player) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme déjà pris.' }));
        } else {
          player = new Player({ username, avatar });
          await player.save();

          activePlayers[username] = { ws, score: 0, startTime: Date.now(), symbol: Object.keys(activePlayers).length === 0 ? 'X' : 'O' };

          // Si aucun joueur n'attend, ce joueur attend un autre joueur
          if (!waitingPlayer) {
            waitingPlayer = username;
            ws.send(JSON.stringify({ type: 'waiting', message: 'En attente d\'un deuxième joueur...' }));
          } else {
            // Un autre joueur est déjà en attente, commencer la partie
            const player1 = waitingPlayer;
            const player2 = username;

            currentPlayer = player1; // Le joueur qui attend commence

            activePlayers[player1].ws.send(JSON.stringify({ type: 'startGame', message: 'La partie commence!', symbol: 'X', board: morpionBoard }));
            activePlayers[player2].ws.send(JSON.stringify({ type: 'startGame', message: 'La partie commence!', symbol: 'O', board: morpionBoard }));

            waitingPlayer = null; // Remettre l'attente à zéro
          }
        }
        break;

      // Les autres cases (comme move, endGame, etc.) suivent
      // ...
    }
  });

  ws.on('close', () => {
    for (const username in activePlayers) {
      if (activePlayers[username].ws === ws) {
        delete activePlayers[username];
        console.log(`Joueur ${username} déconnecté`);
      }
    }
  });
});































    switch (data.type) {
      // Cas 'join': Un joueur rejoint la partie avec un pseudonyme et un avatar
      case 'join':
        const { username, avatar } = data;
        if (!username || !avatar) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme et avatar requis.' }));
          return;
        }

        // Vérifier si le joueur existe déjà dans MongoDB
        let player = await Player.findOne({ username });
        if (player) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme déjà pris.' }));
        } else {
          // Créer un nouveau joueur dans la base de données
          player = new Player({ username, avatar });
          await player.save();

          // Enregistrer le joueur dans la liste active
          activePlayers[username] = { ws, score: 0, startTime: Date.now(), symbol: Object.keys(activePlayers).length === 0 ? 'X' : 'O' };
          ws.send(JSON.stringify({ type: 'joinSuccess', message: `Bienvenue ${username}!`, symbol: activePlayers[username].symbol }));

          if (Object.keys(activePlayers).length === 2) {
            // Si deux joueurs sont connectés, démarrer la partie
            const firstPlayer = Object.keys(activePlayers)[0];
            currentPlayer = firstPlayer;
            broadcast({ type: 'gameStart', message: 'La partie commence!', board: morpionBoard });
            activePlayers[firstPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
          } else {
            // Si un seul joueur est connecté, attendre le deuxième joueur
            ws.send(JSON.stringify({ type: 'waitingForPlayer', message: 'En attente d’un autre joueur...' }));
          }
        }
        break;

      // Cas 'move': Gérer les déplacements dans le jeu
      case 'move':
        const { row, col } = data;
        if (activePlayers[data.username] && data.username === currentPlayer && morpionBoard[row][col] === '') {
          // Marquer le coup sur le plateau
          morpionBoard[row][col] = activePlayers[data.username].symbol;
          movesCount++;

          // Vérifier si le joueur a gagné
          if (checkWin(morpionBoard, activePlayers[data.username].symbol)) {
            activePlayers[data.username].score += 10; // Augmenter le score
            ws.send(JSON.stringify({ type: 'win', message: 'Vous avez gagné!', board: morpionBoard }));
            resetGame();
          } else if (movesCount === 9) {
            // Si tous les mouvements ont été joués et pas de gagnant, match nul
            broadcast({ type: 'draw', message: 'Match nul!', board: morpionBoard });
            resetGame();
          } else {
            // Passer au joueur suivant
            currentPlayer = getNextPlayer(data.username);
            broadcast({ type: 'boardUpdate', board: morpionBoard });
            activePlayers[currentPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
          }
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Coup invalide ou pas votre tour.' }));
        }
        break;

      // Cas 'endGame': Fin de la partie, mise à jour du score final et sauvegarde dans la base de données
      case 'endGame':
        const { username: endUsername } = data;
        if (activePlayers[endUsername]) {
          const endTime = Date.now();
          const playTime = endTime - activePlayers[endUsername].startTime;

          // Mettre à jour le score final et la durée de jeu dans MongoDB
          const playerToUpdate = await Player.findOne({ username: endUsername });
          if (playerToUpdate) {
            playerToUpdate.score = activePlayers[endUsername].score;
            playerToUpdate.playTime = playTime;
            await playerToUpdate.save();
          }

          ws.send(JSON.stringify({ type: 'updateScore', score: activePlayers[endUsername].score, playTime }));
          delete activePlayers[endUsername]; // Retirer le joueur de la liste active
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Joueur non trouvé.' }));
        }
        break;

      // Cas 'restart': Redémarrer la partie
      case 'restart':
        resetGame();
        broadcast({ type: 'gameRestarted', message: 'La partie a été redémarrée.', board: morpionBoard });
        currentPlayer = Object.keys(activePlayers)[0];
        activePlayers[currentPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
        break;

      default:
        ws.send(JSON.stringify({ type: 'error', message: 'Type de message non reconnu.' }));
        break;
    }
  });

  // Gérer la déconnexion des joueurs
  ws.on('close', () => {
    for (const username in activePlayers) {
      if (activePlayers[username].ws === ws) {
        delete activePlayers[username];
        console.log(`Joueur ${username} déconnecté`);
      }
    }
  });
});

// Fonction pour vérifier si un joueur a gagné
function checkWin(board, symbol) {
  // Vérifier les lignes, colonnes et diagonales
  for (let i = 0; i < 3; i++) {
    if (board[i][0] === symbol && board[i][1] === symbol && board[i][2] === symbol) return true;
    if (board[0][i] === symbol && board[1][i] === symbol && board[2][i] === symbol) return true;
  }
  if (board[0][0] === symbol && board[1][1] === symbol && board[2][2] === symbol) return true;
  if (board[0][2] === symbol && board[1][1] === symbol && board[2][0] === symbol) return true;

  return false;
}

// Fonction pour redémarrer le jeu
function resetGame() {
  morpionBoard = [['', '', ''], ['', '', ''], ['', '', '']];
  currentPlayer = null;
  movesCount = 0;
}

// Fonction pour passer au joueur suivant
function getNextPlayer(currentUsername) {
  const players = Object.keys(activePlayers);
  const currentIndex = players.indexOf(currentUsername);
  return players[(currentIndex + 1) % players.length];
}

// Fonction pour envoyer un message à tous les joueurs
function broadcast(message) {
  Object.values(activePlayers).forEach(player => {
    player.ws.send(JSON.stringify(message));
  });
}
*/





































/* Dernier code utilisé : il fonctionne très bien 

const WebSocket = require('ws');
const mongoose = require('mongoose');
const express = require('express');
const app = express();
const PORT = 3000;

// Connexion à MongoDB
mongoose.connect('mongodb://localhost:27017/jeu-multijoueur')
  .then(() => {
    console.log('Connecté à MongoDB');
  })
  .catch((error) => {
    console.error('Erreur de connexion à MongoDB:', error);
  });

// Schéma et modèle de joueur
const playerSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  avatar: { type: String, required: true },
  score: { type: Number, default: 0 },
  playTime: { type: Number, default: 0 } // Temps de jeu en millisecondes
});

const Player = mongoose.model('Player', playerSchema);

// Stocker les joueurs actifs et le plateau du morpion
let activePlayers = {};
let morpionBoard = [['', '', ''], ['', '', ''], ['', '', '']];
let currentPlayer = null;
let movesCount = 0;

// Créer le serveur WebSocket uniquement (sans serveur HTTP pour les fichiers statiques)
const server = app.listen(PORT, () => {
  console.log(`Serveur en écoute sur le port ${PORT}`);
});

const wss = new WebSocket.Server({ server });

// Attendre deux joueurs pour commencer la partie
wss.on('connection', (ws) => {
  console.log('Un nouveau joueur s\'est connecté.');

  ws.on('message', async (message) => {
    console.log('Message reçu:', message);
    const data = JSON.parse(message);

    switch (data.type) {
      case 'join':
        const { username, avatar } = data;
        console.log(`Tentative de connexion de ${username} avec avatar ${avatar}`);

        // Vérifier que le pseudonyme et l'avatar sont fournis
        if (!username || !avatar) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme et avatar requis.' }));
          return;
        }

        // Vérifier si la partie est déjà en cours avec deux joueurs
        if (Object.keys(activePlayers).length >= 2) {
          ws.send(JSON.stringify({ type: 'error', message: 'Partie déjà en cours. Veuillez attendre la fin pour rejoindre.' }));
          return;
        }

        // Vérifier si le joueur existe déjà dans MongoDB ou si le pseudonyme est déjà actif
        let player = await Player.findOne({ username });
        if (player || activePlayers[username]) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme déjà pris.' }));
        } else {
          // Créer un nouveau joueur dans la base de données
          player = new Player({ username, avatar });
          await player.save();

          // Enregistrer le joueur dans la liste active
          activePlayers[username] = { ws, score: 0, startTime: Date.now(), symbol: Object.keys(activePlayers).length === 0 ? 'X' : 'O' };
          
          // Envoyer le message de bienvenue uniquement après l'inscription
          ws.send(JSON.stringify({ type: 'joinSuccess', message: `Bienvenue ${username}!`, symbol: activePlayers[username].symbol }));
          console.log(`Joueur ${username} a rejoint la partie avec le symbole ${activePlayers[username].symbol}`);

          if (Object.keys(activePlayers).length === 2) {
            // Si deux joueurs sont connectés, démarrer la partie
            const firstPlayer = Object.keys(activePlayers)[0];
            currentPlayer = firstPlayer;
            broadcast({ type: 'gameStart', message: 'La partie commence!', board: morpionBoard });
            activePlayers[firstPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
          } else {
            // Si un seul joueur est connecté, attendre le deuxième joueur
            ws.send(JSON.stringify({ type: 'waitingForPlayer', message: 'En attente d’un autre joueur...' }));
          }
        }
        break;

      case 'move':
        const { row, col } = data;
        console.log(`Joueur ${data.username} fait un mouvement à (${row}, ${col})`);

        if (activePlayers[data.username] && data.username === currentPlayer && morpionBoard[row][col] === '') {
          // Marquer le coup sur le plateau
          morpionBoard[row][col] = activePlayers[data.username].symbol;
          movesCount++;

          // Vérifier si le joueur a gagné
          if (checkWin(morpionBoard, activePlayers[data.username].symbol)) {
            activePlayers[data.username].score += 10; // Augmenter le score
            ws.send(JSON.stringify({ type: 'win', message: 'Vous avez gagné!', board: morpionBoard }));
            resetGame();
          } else if (movesCount === 9) {
            // Si tous les mouvements ont été joués et pas de gagnant, match nul
            broadcast({ type: 'draw', message: 'Match nul!', board: morpionBoard });
            resetGame();
          } else {
            // Passer au joueur suivant
            currentPlayer = getNextPlayer(data.username);
            broadcast({ type: 'boardUpdate', board: morpionBoard });
            activePlayers[currentPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
          }
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Coup invalide ou pas votre tour.' }));
        }
        break;

      case 'endGame':
        const { username: endUsername } = data;
        console.log(`Fin de jeu pour le joueur ${endUsername}`);

        if (activePlayers[endUsername]) {
          const endTime = Date.now();
          const playTime = endTime - activePlayers[endUsername].startTime;

          // Mettre à jour le score final et la durée de jeu dans MongoDB
          const playerToUpdate = await Player.findOne({ username: endUsername });
          if (playerToUpdate) {
            playerToUpdate.score = activePlayers[endUsername].score;
            playerToUpdate.playTime = playTime;
            await playerToUpdate.save();
          }

          ws.send(JSON.stringify({ type: 'updateScore', score: activePlayers[endUsername].score, playTime }));
          delete activePlayers[endUsername]; // Retirer le joueur de la liste active
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Joueur non trouvé.' }));
        }
        break;

      case 'restart':
        console.log('Redémarrage de la partie');
        resetGame();
        broadcast({ type: 'gameRestarted', message: 'La partie a été redémarrée.', board: morpionBoard });
        currentPlayer = Object.keys(activePlayers)[0];
        activePlayers[currentPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
        break;

      default:
        ws.send(JSON.stringify({ type: 'error', message: 'Type de message non reconnu.' }));
        break;
    }
  });

  // Gérer la déconnexion des joueurs et sauvegarde du score
  ws.on('close', async () => {
    console.log('Un joueur s\'est déconnecté.');
    for (const username in activePlayers) {
      if (activePlayers[username].ws === ws) {
        const endTime = Date.now();
        const playTime = endTime - activePlayers[username].startTime;

        // Sauvegarder les données du joueur avant de le déconnecter
        const playerToUpdate = await Player.findOne({ username });
        if (playerToUpdate) {
          playerToUpdate.score = activePlayers[username].score;
          playerToUpdate.playTime = playTime;
          await playerToUpdate.save();
        }

        delete activePlayers[username];
        console.log(`Joueur ${username} déconnecté.`);
      }
    }
  });
});

// Fonction pour vérifier si un joueur a gagné
function checkWin(board, symbol) {
  // Vérifier les lignes, colonnes et diagonales
  for (let i = 0; i < 3; i++) {
    if (board[i][0] === symbol && board[i][1] === symbol && board[i][2] === symbol) return true;
    if (board[0][i] === symbol && board[1][i] === symbol && board[2][i] === symbol) return true;
  }
  if (board[0][0] === symbol && board[1][1] === symbol && board[2][2] === symbol) return true;
  if (board[0][2] === symbol && board[1][1] === symbol && board[2][0] === symbol) return true;

  return false;
}

// Fonction pour redémarrer le jeu
function resetGame() {
  morpionBoard = [['', '', ''], ['', '', ''], ['', '', '']];
  currentPlayer = null;
  movesCount = 0;
}

// Fonction pour passer au joueur suivant
function getNextPlayer(currentUsername) {
  const players = Object.keys(activePlayers);
  const currentIndex = players.indexOf(currentUsername);
  return players[(currentIndex + 1) % players.length];
}

// Fonction pour envoyer un message à tous les joueurs
function broadcast(message) {
  Object.values(activePlayers).forEach(player => {
    player.ws.send(JSON.stringify(message));
  });
}
*/





















































const WebSocket = require('ws');
const mongoose = require('mongoose');
const express = require('express');
const app = express();
const PORT = 3000;

// Connexion à MongoDB
mongoose.connect('mongodb://localhost:27017/jeu-multijoueur')
  .then(() => {
    console.log('Connecté à MongoDB');
  })
  .catch((error) => {
    console.error('Erreur de connexion à MongoDB:', error);
  });

// Schéma et modèle de joueur
const playerSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  avatar: { type: String, required: true },
  score: { type: Number, default: 0 },
  playTime: { type: Number, default: 0 } // Temps de jeu en millisecondes
});

const Player = mongoose.model('Player', playerSchema);

// Stocker les joueurs actifs et le plateau du morpion
let activePlayers = {};
let morpionBoard = [['', '', ''], ['', '', ''], ['', '', '']];
let currentPlayer = null;
let movesCount = 0;

// Créer le serveur WebSocket uniquement (sans serveur HTTP pour les fichiers statiques)
const server = app.listen(PORT, () => {
  console.log(`Serveur en écoute sur le port ${PORT}`);
});

const wss = new WebSocket.Server({ server });

// Attendre deux joueurs pour commencer la partie
wss.on('connection', (ws) => {
  console.log('Un nouveau joueur s\'est connecté.');

  ws.on('message', async (message) => {
    console.log('Message reçu:', message);
    const data = JSON.parse(message);

    switch (data.type) {
      case 'join':
        const { username, avatar } = data;
        console.log(`Données reçues : username=${data.username}, avatar=${data.avatar}`);
        console.log(`Tentative de connexion de ${username} avec avatar ${avatar}`);

        // Vérifier que le pseudonyme et l'avatar sont fournis
        if (!username || !avatar) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme et avatar requis.' }));
          return;
        }

        // Vérifier si la partie est déjà en cours avec deux joueurs
        if (Object.keys(activePlayers).length >= 2) {
          ws.send(JSON.stringify({ type: 'error', message: 'Partie déjà en cours. Veuillez attendre la fin pour rejoindre.' }));
          return;
        }

        // Vérifier si le joueur existe déjà dans MongoDB ou si le pseudonyme est déjà actif
        let player = await Player.findOne({ username });
        console.log('Résultat de recherche MongoDB : ', player);

        if (player || activePlayers[username]) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme déjà pris.' }));
          console.log('Erreur : Pseudonyme déjà pris');
        } else {
          // Créer un nouveau joueur dans la base de données
          player = new Player({ username, avatar });
          await player.save();

          // Enregistrer le joueur dans la liste active
          activePlayers[username] = { ws, score: 0, startTime: Date.now(), symbol: Object.keys(activePlayers).length === 0 ? 'X' : 'O' };
          
          // Envoyer le message de bienvenue uniquement après l'inscription
          ws.send(JSON.stringify({ type: 'joinSuccess', message: `Bienvenue ${username}!`, symbol: activePlayers[username].symbol }));
          console.log(`Joueur ${username} a rejoint la partie avec le symbole ${activePlayers[username].symbol}`);

          if (Object.keys(activePlayers).length === 2) {
            console.log('Nombre de joueurs actifs : ', Object.keys(activePlayers).length);
            // Si deux joueurs sont connectés, démarrer la partie
            const firstPlayer = Object.keys(activePlayers)[0];
            currentPlayer = firstPlayer;
            console.log('Envoi du message gameStart à tous les joueurs');
            broadcast({ type: 'gameStart', message: 'La partie commence!', board: morpionBoard });
            activePlayers[firstPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
          } else {
            // Si un seul joueur est connecté, attendre le deuxième joueur
            ws.send(JSON.stringify({ type: 'waitingForPlayer', message: 'En attente d’un autre joueur...' }));
          }
        }
        break;

      case 'move':
        const { row, col } = data;
        console.log(`Joueur ${data.username} fait un mouvement à (${row}, ${col})`);

        if (activePlayers[data.username] && data.username === currentPlayer && morpionBoard[row][col] === '') {
          // Marquer le coup sur le plateau
          morpionBoard[row][col] = activePlayers[data.username].symbol;
          movesCount++;
          console.log('Plateau mis à jour : ', morpionBoard);

          // Vérifier si le joueur a gagné
          if (checkWin(morpionBoard, activePlayers[data.username].symbol)) {
            activePlayers[data.username].score += 10; // Augmenter le score
            ws.send(JSON.stringify({ type: 'win', message: 'Vous avez gagné!', board: morpionBoard }));
            resetGame();
          } else if (movesCount === 9) {
            // Si tous les mouvements ont été joués et pas de gagnant, match nul
            broadcast({ type: 'draw', message: 'Match nul!', board: morpionBoard });
            resetGame();
          } else {
            // Passer au joueur suivant
            currentPlayer = getNextPlayer(data.username);
            console.log(`C'est au tour de ${currentPlayer}`);
            broadcast({ type: 'boardUpdate', board: morpionBoard });
            activePlayers[currentPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
          }
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Coup invalide ou pas votre tour.' }));
          console.log('Erreur : Pas le tour de ce joueur.');
        }
        break;

      case 'endGame':
        const { username: endUsername } = data;
        console.log(`Fin de jeu pour le joueur ${endUsername}`);

        if (activePlayers[endUsername]) {
          const endTime = Date.now();
          const playTime = endTime - activePlayers[endUsername].startTime;

          // Mettre à jour le score final et la durée de jeu dans MongoDB
          const playerToUpdate = await Player.findOne({ username: endUsername });
          if (playerToUpdate) {
            playerToUpdate.score = activePlayers[endUsername].score;
            playerToUpdate.playTime = playTime;
            await playerToUpdate.save();
            console.log('Joueur mis à jour dans MongoDB : ', playerToUpdate);
          }

          ws.send(JSON.stringify({ type: 'updateScore', score: activePlayers[endUsername].score, playTime }));
          delete activePlayers[endUsername]; // Retirer le joueur de la liste active
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Joueur non trouvé.' }));
        }
        break;

      case 'restart':
        console.log('Redémarrage de la partie');
        resetGame();
        broadcast({ type: 'gameRestarted', message: 'La partie a été redémarrée.', board: morpionBoard });
        currentPlayer = Object.keys(activePlayers)[0];
        activePlayers[currentPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
        break;

      default:
        ws.send(JSON.stringify({ type: 'error', message: 'Type de message non reconnu.' }));
        break;
    }
  });

  // Gérer la déconnexion des joueurs et sauvegarde du score
  ws.on('close', async () => {
    console.log('Un joueur s\'est déconnecté.');
    for (const username in activePlayers) {
      if (activePlayers[username].ws === ws) {
        const endTime = Date.now();
        const playTime = endTime - activePlayers[username].startTime;

        // Sauvegarder les données du joueur avant de le déconnecter
        const playerToUpdate = await Player.findOne({ username });
        if (playerToUpdate) {
          playerToUpdate.score = activePlayers[username].score;
          playerToUpdate.playTime = playTime;
          await playerToUpdate.save();
          console.log(`Joueur ${username} mis à jour dans MongoDB après déconnexion`);
        }

        delete activePlayers[username];
        console.log(`Joueur ${username} déconnecté et retiré de la liste active.`);
      }
    }
  });
});

// Fonction pour vérifier si un joueur a gagné
function checkWin(board, symbol) {
  // Vérifier les lignes, colonnes et diagonales
  for (let i = 0; i < 3; i++) {
    if (board[i][0] === symbol && board[i][1] === symbol && board[i][2] === symbol) return true;
    if (board[0][i] === symbol && board[1][i] === symbol && board[2][i] === symbol) return true;
  }
  if (board[0][0] === symbol && board[1][1] === symbol && board[2][2] === symbol) return true;
  if (board[0][2] === symbol && board[1][1] === symbol && board[2][0] === symbol) return true;

  return false;
}

// Fonction pour redémarrer le jeu
function resetGame() {
  morpionBoard = [['', '', ''], ['', '', ''], ['', '', '']];
  currentPlayer = null;
  movesCount = 0;
}

// Fonction pour passer au joueur suivant
function getNextPlayer(currentUsername) {
  const players = Object.keys(activePlayers);
  const currentIndex = players.indexOf(currentUsername);
  return players[(currentIndex + 1) % players.length];
}

// Fonction pour envoyer un message à tous les joueurs
function broadcast(message) {
  Object.values(activePlayers).forEach(player => {
    player.ws.send(JSON.stringify(message));
  });
}


