const WebSocket = require('ws');
const server = new WebSocket.Server({ port: 3000 });

let activePlayers = {};  // Pour stocker les joueurs connectés et leurs scores

server.on('connection', (ws) => {
    ws.on('message', (message) => {
        const data = JSON.parse(message);
        if (data.type === 'join') {
            // Enregistrer le joueur
            activePlayers[data.username] = { score: 0, startTime: Date.now() };
            ws.send(JSON.stringify({ type: 'joinSuccess', message: `Bienvenue ${data.username}!` }));
        }

        // Autres types de messages comme 'move', 'endGame', etc.
    });

    ws.on('close', () => {
        // Gérer la déconnexion du joueur
    });
});




// Gérer la connexion des joueurs
server.on('connection', (ws) => {
    ws.on('message', (message) => {
        const data = JSON.parse(message);

        // Quand un joueur rejoint
        if (data.type === 'join') {
            const username = data.username;

            // Enregistrer le joueur avec un score initial et l'heure de début de jeu
            if (!activePlayers[username]) {
                activePlayers[username] = { score: 0, startTime: Date.now() };
                ws.send(JSON.stringify({ type: 'joinSuccess', message: `Bienvenue ${username}!` }));
            } else {
                ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme déjà pris.' }));
            }
        }

        // Autres types de messages comme 'move', 'endGame', etc.
        if (data.type === 'move') {
            // Gérer les mouvements du jeu, mise à jour des scores...
        }

        if (data.type === 'endGame') {
            const username = data.username;
            if (activePlayers[username]) {
                const endTime = Date.now();
                const playTime = endTime - activePlayers[username].startTime;

                // Mettre à jour le score, ou faire d'autres actions
                activePlayers[username].score += 10;  // Exemple de score
                ws.send(JSON.stringify({ type: 'updateScore', score: activePlayers[username].score }));
            }
        }
    });

    // Gérer la déconnexion
    ws.on('close', () => {
        // Supprimer le joueur de la liste s'il se déconnecte
        // delete activePlayers[username];
    });
});





console.log('Le serveur WebSocket est en écoute sur le port 3000');


