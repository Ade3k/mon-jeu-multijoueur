const socket = new WebSocket('ws://localhost:3000');
const loginForm = document.getElementById('loginForm');
const gameContainer = document.getElementById('gameContainer');
const message = document.getElementById('message');

document.getElementById('startGame').addEventListener('click', (event) => {
    event.preventDefault();
    const username = document.getElementById('username').value.trim();
    if (username) {
        socket.send(JSON.stringify({ type: 'join', username }));
        loginForm.style.display = 'none';
        gameContainer.style.display = 'block';
        message.textContent = `Bienvenue ${username}! Prêt à jouer?`;
    }
});

socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.type === 'joinSuccess') {
        message.textContent = data.message;
    }
};

const socket = new WebSocket('ws://localhost:3000'); // Connexion au serveur WebSocket
let selectedAvatar = ''; // Pour stocker l'avatar sélectionné
let usernames = new Set(); // Pour stocker les noms d'utilisateur uniques





// Gestion de la sélection de l'avatar
document.querySelectorAll('.avatar-option').forEach(img => {
    img.addEventListener('click', () => {
        // Retirer la classe 'selected' de tous les avatars
        document.querySelectorAll('.avatar-option').forEach(avatar => avatar.classList.remove('selected'));

        // Ajouter la classe 'selected' à l'avatar cliqué
        img.classList.add('selected');

        // Sauvegarder l'avatar sélectionné
        selectedAvatar = img.getAttribute('data-avatar');
        console.log(`Avatar sélectionné : ${selectedAvatar}`); // Vérifiez dans la console
    });
});






// Fonction pour démarrer la partie
function startGame() {
    const username = document.getElementById('username').value.trim();

    if (!username) {
        alert('Veuillez entrer un pseudonyme.');
        return;
    }

    if (!selectedAvatar) {
        alert('Veuillez sélectionner un avatar.');
        return;
    }

    // Vérifier si le pseudonyme est déjà pris
    if (usernames.has(username)) {
        alert('Ce pseudonyme est déjà utilisé. Veuillez en choisir un autre.');
        return;
    }

    // Si tout est valide, enregistrer le pseudonyme et l'avatar
    usernames.add(username);
    socket.send(JSON.stringify({ type: 'join', username, avatar: selectedAvatar }));

    // Rediriger vers la page du jeu
    window.location.href = 'PageJeu.html?username=' + encodeURIComponent(username) + '&avatar=' + encodeURIComponent(selectedAvatar);
}

// Gestion de la sélection de l'avatar
document.querySelectorAll('.avatar-option').forEach(img => {
    img.addEventListener('click', () => {
        // Retirer la classe 'selected' de tous les avatars
        document.querySelectorAll('.avatar-option').forEach(avatar => avatar.classList.remove('selected'));

        // Ajouter la classe 'selected' à l'avatar cliqué
        img.classList.add('selected');

        // Sauvegarder l'avatar sélectionné
        selectedAvatar = img.getAttribute('data-avatar');
    });
});

// Ajout d'un événement au bouton Commencer
document.getElementById('startGame').addEventListener('click', startGame);
 





































































































/* 
const socket = new WebSocket('ws://localhost:3000'); // Connexion au serveur WebSocket

const cells = document.querySelectorAll('.cell');
const message = document.getElementById('message');
const restartButton = document.getElementById('restartButton');
const loginForm = document.getElementById('loginForm');
const usernameInput = document.getElementById('username');
const startGameButton = document.getElementById('startGame');
const scoreList = document.getElementById('scoreList');

let username = ''; // Pseudonyme du joueur
let currentPlayer = 'X';
let board = ['', '', '', '', '', '', '', '', ''];
let isGameActive = true;

// Les conditions de victoire
const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

// Envoi du pseudonyme lors du démarrage
startGameButton.addEventListener('click', (e) => {
    e.preventDefault();
    username = usernameInput.value;
    
    if (username) {
        socket.send(JSON.stringify({
            type: 'join',
            username: username
        }));

        loginForm.style.display = 'none'; // Masquer le formulaire après la connexion
    }
});

// Fonction pour vérifier si un joueur a gagné
const checkWin = () => {
    let roundWon = false;
    for (let i = 0; i < winningConditions.length; i++) {
        const winCondition = winningConditions[i];
        const a = board[winCondition[0]];
        const b = board[winCondition[1]];
        const c = board[winCondition[2]];
        if (a === '' || b === '' || c === '') {
            continue;
        }
        if (a === b && b === c) {
            roundWon = true;
            break;
        }
    }
    if (roundWon) {
        message.textContent = `Le joueur ${currentPlayer} a gagné!`;
        isGameActive = false;

        // Envoi du score au serveur
        socket.send(JSON.stringify({
            type: 'gameEnd',
            winner: username
        }));

        return;
    }

    if (!board.includes('')) {
        message.textContent = 'Match nul!';
        isGameActive = false;
        return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    message.textContent = `C'est le tour du joueur ${currentPlayer}`;
};

// Gestion du clic sur les cases
const handleCellClick = (e) => {
    const clickedCell = e.target;
    const clickedCellIndex = parseInt(clickedCell.getAttribute('data-index'));

    if (board[clickedCellIndex] !== '' || !isGameActive) {
        return;
    }

    // Mise à jour locale de l'état du jeu
    board[clickedCellIndex] = currentPlayer;
    clickedCell.textContent = currentPlayer;

    // Envoi du mouvement au serveur
    socket.send(JSON.stringify({
        type: 'move',
        player: currentPlayer,
        board: board
    }));

    checkWin();
};

// Réception des mises à jour du serveur
socket.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.type === 'move') {
        board = data.board;

        // Mettre à jour l'affichage local du plateau de jeu
        cells.forEach((cell, index) => {
            cell.textContent = board[index];
        });

        checkWin();
    }

    if (data.type === 'updateScores') {
        // Affichage des scores
        scoreList.innerHTML = ''; // Vider la liste des scores actuels
        data.scores.forEach(score => {
            const li = document.createElement('li');
            li.textContent = `${score.username}: ${score.score} points`;
            scoreList.appendChild(li);
        });
    }
};

// Pour relancer le jeu
const restartGame = () => {
    currentPlayer = 'X';
    board = ['', '', '', '', '', '', '', '', ''];
    isGameActive = true;
    message.textContent = `C'est le tour du joueur ${currentPlayer}`;
    cells.forEach(cell => cell.textContent = '');

    // Envoi de la commande de redémarrage au serveur
    socket.send(JSON.stringify({
        type: 'restart'
    }));
};

// Ajout des événements de clic sur les cases
cells.forEach(cell => cell.addEventListener('click', handleCellClick));
restartButton.addEventListener('click', restartGame);

message.textContent = `C'est le tour du joueur ${currentPlayer}`;

*/