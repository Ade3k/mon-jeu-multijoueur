const socket = new WebSocket('ws://localhost:3000');
const cells = document.querySelectorAll('.cell');
let currentPlayerSymbol = '';
let board = ['', '', '', '', '', '', '', '', ''];
let isGameActive = true;

socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log('Message reçu:', data);

    switch (data.type) {
        case 'gameStart':
            board = data.board;
            updateBoard(board);
            break;

        case 'yourTurn':
            document.getElementById('message').textContent = 'C\'est ton tour!';
            updateBoard(data.board);
            break;

        case 'boardUpdate':
            updateBoard(data.board);
            break;

        case 'win':
            document.getElementById('message').textContent = 'Vous avez gagné!';
            updateBoard(data.board);
            isGameActive = false;
            break;

        case 'draw':
            document.getElementById('message').textContent = 'Match nul!';
            updateBoard(data.board);
            isGameActive = false;
            break;

        default:
            console.log('Message non géré:', data);
    }
};

function updateBoard(currentBoard) {
    cells.forEach((cell, index) => {
        cell.textContent = currentBoard[index];
        if (!cell.textContent) {
            cell.addEventListener('click', () => handleCellClick(index), { once: true });
        }
    });
}

function handleCellClick(index) {
    if (!isGameActive || board[index] !== '') return;
    
    board[index] = currentPlayerSymbol;
    socket.send(JSON.stringify({ type: 'move', board }));
    updateBoard(board);
}

document.getElementById('restartButton').addEventListener('click', () => {
    socket.send(JSON.stringify({ type: 'restart' }));
    isGameActive = true;
});






































































































/* Dernier code utilisé : il fonctionne très bien 

const socket = new WebSocket('ws://localhost:3000');
const loginForm = document.getElementById('loginForm');
const gameContainer = document.getElementById('gameContainer');
const message = document.getElementById('message');
const cells = document.querySelectorAll('.cell'); // Assurez-vous que chaque cellule a une classe 'cell'
const restartButton = document.getElementById('restartButton');

let selectedAvatar = ''; // Pour stocker l'avatar sélectionné
let usernames = new Set(); // Pour stocker les noms d'utilisateur uniques
let currentPlayerSymbol = ''; // Pour stocker le symbole du joueur courant
let board = ['', '', '', '', '', '', '', '', ''];
let isGameActive = true;

// Fonction pour démarrer la partie
function startGame() {
    const username = document.getElementById('username').value.trim();

    if (!username) {
        alert('Veuillez entrer un pseudonyme.');
        return;
    }

    if (!selectedAvatar) {
        alert('Veuillez sélectionner un avatar.');
        return;
    }

    // Vérifier si le pseudonyme est déjà pris
    if (usernames.has(username)) {
        alert('Ce pseudonyme est déjà utilisé. Veuillez en choisir un autre.');
        return;
    }

    usernames.add(username); // Ajouter le pseudonyme au Set
    socket.send(JSON.stringify({ type: 'join', username, avatar: selectedAvatar }));
}

// Gestion de la sélection de l'avatar
document.querySelectorAll('.avatar-option').forEach(img => {
    img.addEventListener('click', () => {
        document.querySelectorAll('.avatar-option').forEach(avatar => avatar.classList.remove('selected'));
        img.classList.add('selected');
        selectedAvatar = img.getAttribute('data-avatar');
    });
});

// Ajout d'un événement au bouton Commencer
document.getElementById('startGame').addEventListener('click', startGame);

// Événements du WebSocket
socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log('Message reçu:', data);

    switch (data.type) {
        case 'joinSuccess':
            message.textContent = data.message;
            playerOneInfo.textContent = `Joueur 1: ${data.username} (${data.avatar})`;
            playerOneInfo.style.display = 'block'; 
            break;

        case 'playerTwoJoined':
            playerTwoInfo.textContent = `Joueur 2: ${data.username} (${data.avatar})`;
            playerTwoInfo.style.display = 'block';
            break;

        case 'waiting':
            message.textContent = data.message;
            break;

        case 'gameStart':
            startGame(data.symbol, data.board);
            break;

        case 'yourTurn':
            message.textContent = 'C\'est ton tour!';
            updateBoard(data.board);
            break;

        case 'boardUpdate':
            updateBoard(data.board);
            break;

        case 'win':
            message.textContent = 'Vous avez gagné!';
            updateBoard(data.board);
            isGameActive = false; // Désactiver les clics sur le plateau
            break;

        case 'draw':
            message.textContent = 'Match nul!';
            updateBoard(data.board);
            isGameActive = false;
            break;

        default:
            message.textContent = data.message;
            break;
    }
};

function startGame(symbol, initialBoard) {
    currentPlayerSymbol = symbol;
    board = initialBoard; // Initialiser le tableau de jeu
    isGameActive = true;
    updateBoard(board);
    loginForm.style.display = 'none';
    gameContainer.style.display = 'block';
}

function updateBoard(currentBoard) {
    board = currentBoard;
    cells.forEach((cell, index) => {
        cell.textContent = board[index];
        cell.addEventListener('click', () => handleCellClick(index), { once: true }); // Écouter un clic par cellule
    });
}

function handleCellClick(index) {
    if (!isGameActive || board[index] !== '') return; // Vérifiez si le jeu est actif et si la case est vide

    board[index] = currentPlayerSymbol; // Mettre à jour le tableau local
    socket.send(JSON.stringify({ type: 'move', board })); // Envoyer le mouvement au serveur
    updateBoard(board); // Mettre à jour le plateau affiché
    checkWin(); // Vérifier si le joueur a gagné
}

function checkWin() {
    const winningConditions = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    for (let condition of winningConditions) {
        const [a, b, c] = condition;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            message.textContent = `${board[a]} a gagné!`;
            isGameActive = false;
            return;
        }
    }

    if (!board.includes('')) {
        message.textContent = 'Match nul!';
        isGameActive = false;
    }
}

// Réinitialiser le jeu
restartButton.addEventListener('click', () => {
    board = ['', '', '', '', '', '', '', '', ''];
    isGameActive = true;
    message.textContent = `C'est le tour de ${currentPlayerSymbol}`;
    cells.forEach(cell => cell.textContent = '');
    socket.send(JSON.stringify({ type: 'restart' })); // Demander la réinitialisation au serveur
});

// Assurez-vous de mettre à jour l'affichage du message initial
message.textContent = 'Veuillez vous connecter et sélectionner un avatar pour commencer.';
*/













































/*
OPTION 2

const socket = new WebSocket('ws://localhost:3000');
const loginForm = document.getElementById('loginForm');
const gameContainer = document.getElementById('gameContainer');
const message = document.getElementById('message');

// Éléments pour afficher les informations des joueurs
const playerOneInfo = document.getElementById('playerOneInfo'); // Info joueur 1
const playerTwoInfo = document.getElementById('playerTwoInfo'); // Info joueur 2

let selectedAvatar = ''; // Pour stocker l'avatar sélectionné
let usernames = new Set(); // Pour stocker les noms d'utilisateur uniques
let isGameStarted = false; // Pour indiquer si la partie a commencé

// Fonction pour démarrer la connexion du joueur
function startGame() {
    const username = document.getElementById('username').value.trim();

    if (!username) {
        alert('Veuillez entrer un pseudonyme.');
        return;
    }

    if (!selectedAvatar) {
        alert('Veuillez sélectionner un avatar.');
        return;
    }

    // Vérifier si le pseudonyme est déjà pris
    if (usernames.has(username)) {
        alert('Ce pseudonyme est déjà utilisé. Veuillez en choisir un autre.');
        return;
    }

    // Envoyer la demande de connexion au serveur
    socket.send(JSON.stringify({ type: 'join', username, avatar: selectedAvatar }));
}

// Gestion de la sélection de l'avatar
document.querySelectorAll('.avatar-option').forEach(img => {
    img.addEventListener('click', () => {
        // Retirer la classe 'selected' de tous les avatars
        document.querySelectorAll('.avatar-option').forEach(avatar => avatar.classList.remove('selected'));

        // Ajouter la classe 'selected' à l'avatar cliqué
        img.classList.add('selected');

        // Sauvegarder l'avatar sélectionné
        selectedAvatar = img.getAttribute('data-avatar');
    });
});

// Ajout d'un événement au bouton Commencer
document.getElementById('startGame').addEventListener('click', startGame);

socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log('Message reçu:', data); // Log de tous les messages reçus

    switch (data.type) {
        case 'joinSuccess':
            message.textContent = data.message;
            isGameStarted = data.isGameStarted; // Mettre à jour l'état de la partie

            // Afficher les informations du joueur 1 (celui qui vient de se connecter)
            playerOneInfo.textContent = `Joueur 1: ${data.username} (${data.avatar})`;
            playerOneInfo.style.display = 'block'; // Afficher le joueur 1

            // Si la partie commence, afficher le conteneur de jeu
            if (isGameStarted) {
                loginForm.style.display = 'none';
                gameContainer.style.display = 'block';
            }
            break;

        case 'playerTwoJoined':
            // Afficher les informations du joueur 2
            playerTwoInfo.textContent = `Joueur 2: ${data.username} (${data.avatar})`;
            playerTwoInfo.style.display = 'block'; // Afficher le joueur 2
            break;

        case 'waiting':
            // Si la partie est pleine, informer le joueur qu'il doit patienter
            message.textContent = data.message;
            break;

        case 'gameStart':
            // La partie peut commencer, afficher le plateau de jeu
            message.textContent = data.message;
            startGame(data.symbol, data.board);
            break;

        case 'yourTurn':
            message.textContent = 'C\'est ton tour!';
            updateBoard(data.board);
            break;

        case 'boardUpdate':
            updateBoard(data.board);
            break;

        case 'win':
            message.textContent = 'Vous avez gagné!';
            updateBoard(data.board);
            break;

        case 'draw':
            message.textContent = 'Match nul!';
            updateBoard(data.board);
            break;

        default:
            message.textContent = data.message;
            break;
    }
};

function startGame(symbol, board) {
    // Initialiser le plateau de jeu avec le symbole du joueur et afficher le plateau
    currentPlayerSymbol = symbol;
    updateBoard(board);
}

function updateBoard(board) {
    // Mettre à jour l'interface graphique du morpion avec l'état actuel du plateau
    // Ajoutez ici le code qui affiche le plateau de jeu
}
*/













































































/*
// TRES BON CODE QUI FAIT TOUT CE QUI EST DEMANDÉ

const socket = new WebSocket('ws://localhost:3000');
const loginForm = document.getElementById('loginForm');
const gameContainer = document.getElementById('gameContainer');
const message = document.getElementById('message');

let selectedAvatar = ''; // Pour stocker l'avatar sélectionné
let usernames = new Set(); // Pour stocker les noms d'utilisateur uniques

// Fonction pour démarrer la partie
function startGame() {
    const username = document.getElementById('username').value.trim();

    if (!username) {
        alert('Veuillez entrer un pseudonyme.');
        return;
    }

    if (!selectedAvatar) {
        alert('Veuillez sélectionner un avatar.');
        return;
    }

    // Vérifier si le pseudonyme est déjà pris
    if (usernames.has(username)) {
        alert('Ce pseudonyme est déjà utilisé. Veuillez en choisir un autre.');
        return;
    }

    // Si tout est valide, enregistrer le pseudonyme et l'avatar
    usernames.add(username);
    socket.send(JSON.stringify({ type: 'join', username, avatar: selectedAvatar }));

    // Rediriger vers la page du jeu
    // Remplacez cette ligne par la logique que vous souhaitez pour afficher le jeu
    message.textContent = `Bienvenue ${username}! Prêt à jouer?`;
    loginForm.style.display = 'none';
    gameContainer.style.display = 'block';
}

// Gestion de la sélection de l'avatar
document.querySelectorAll('.avatar-option').forEach(img => {
    img.addEventListener('click', () => {
        // Retirer la classe 'selected' de tous les avatars
        document.querySelectorAll('.avatar-option').forEach(avatar => avatar.classList.remove('selected'));

        // Ajouter la classe 'selected' à l'avatar cliqué
        img.classList.add('selected');

        // Sauvegarder l'avatar sélectionné
        selectedAvatar = img.getAttribute('data-avatar');
    });
});

// Ajout d'un événement au bouton Commencer
document.getElementById('startGame').addEventListener('click', startGame);

socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log('Message reçu:', data); // Log de tous les messages reçus

    switch (data.type) {
        case 'joinSuccess':
            message.textContent = data.message;
            break;

        case 'waiting':
            // Le premier joueur doit attendre un autre joueur
            message.textContent = data.message;
            break;

        case 'gameStart':
            // La partie peut commencer, afficher le plateau de jeu
            message.textContent = data.message;
            startGame(data.symbol, data.board);
            break;

        case 'yourTurn':
            message.textContent = 'C\'est ton tour!';
            updateBoard(data.board);
            break;

        case 'boardUpdate':
            updateBoard(data.board);
            break;

        case 'win':
            message.textContent = 'Vous avez gagné!';
            updateBoard(data.board);
            break;

        case 'draw':
            message.textContent = 'Match nul!';
            updateBoard(data.board);
            break;

        default:
            message.textContent = data.message;
            break;
    }
};

function startGame(symbol, board) {
    // Initialiser le plateau de jeu avec le symbole du joueur et afficher le plateau
    currentPlayerSymbol = symbol;
    updateBoard(board);
}

function updateBoard(board) {
    // Mettre à jour l'interface graphique du morpion avec l'état actuel du plateau
    // Ajoutez ici le code qui affiche le plateau de jeu
}
*/






























































































/*
const socket = new WebSocket('ws://localhost:3000');
const loginForm = document.getElementById('loginForm');
const gameContainer = document.getElementById('gameContainer');
const message = document.getElementById('message');

document.getElementById('startGame').addEventListener('click', (event) => {
    event.preventDefault();
    const username = document.getElementById('username').value.trim();
    if (username) {
        socket.send(JSON.stringify({ type: 'join', username }));
        loginForm.style.display = 'none';
        gameContainer.style.display = 'block';
        message.textContent = `Bienvenue ${username}! Prêt à jouer?`;
    }
});

socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.type === 'joinSuccess') {
        message.textContent = data.message;
    }
};

WebSocket
let selectedAvatar = ''; // Pour stocker l'avatar sélectionné
let usernames = new Set(); // Pour stocker les noms d'utilisateur uniques

// Fonction pour démarrer la partie
function startGame() {
    const username = document.getElementById('username').value.trim();

    if (!username) {
        alert('Veuillez entrer un pseudonyme.');
        return;
    }

    if (!selectedAvatar) {
        alert('Veuillez sélectionner un avatar.');
        return;
    }

    // Vérifier si le pseudonyme est déjà pris
    if (usernames.has(username)) {
        alert('Ce pseudonyme est déjà utilisé. Veuillez en choisir un autre.');
        return;
    }

    // Si tout est valide, enregistrer le pseudonyme et l'avatar
    usernames.add(username);
    socket.send(JSON.stringify({ type: 'join', username, avatar: selectedAvatar }));

    // Rediriger vers la page du jeu
    window.location.href = 'PageJeu.html?username=' + encodeURIComponent(username) + '&avatar=' + encodeURIComponent(selectedAvatar);
}

// Gestion de la sélection de l'avatar
document.querySelectorAll('.avatar-option').forEach(img => {
    img.addEventListener('click', () => {
        // Retirer la classe 'selected' de tous les avatars
        document.querySelectorAll('.avatar-option').forEach(avatar => avatar.classList.remove('selected'));

        // Ajouter la classe 'selected' à l'avatar cliqué
        img.classList.add('selected');

        // Sauvegarder l'avatar sélectionné
        selectedAvatar = img.getAttribute('data-avatar');
    });
});

// Ajout d'un événement au bouton Commencer
document.getElementById('startGame').addEventListener('click', startGame);
+/





































socket.onmessage = (event) => {
  const data = JSON.parse(event.data);

  switch (data.type) {
    case 'joinSuccess':
      message.textContent = data.message;
      break;

    case 'waiting':
      // Le premier joueur doit attendre un autre joueur
      message.textContent = data.message;
      break;

    case 'startGame':
      // La partie peut commencer, afficher le plateau de jeu
      message.textContent = data.message;
      startGame(data.symbol, data.board);
      break;

    case 'yourTurn':
      message.textContent = 'C\'est ton tour!';
      updateBoard(data.board);
      break;

    case 'boardUpdate':
      updateBoard(data.board);
      break;

    case 'win':
      message.textContent = 'Vous avez gagné!';
      updateBoard(data.board);
      break;

    case 'draw':
      message.textContent = 'Match nul!';
      updateBoard(data.board);
      break;

    default:
      message.textContent = data.message;
      break;
  }
};












function startGame(symbol, board) {
  // Initialiser le plateau de jeu avec le symbole du joueur et afficher le plateau
  currentPlayerSymbol = symbol;
  updateBoard(board);
}

function updateBoard(board) {
  // Mettre à jour l'interface graphique du morpion avec l'état actuel du plateau
  // Tu dois ajouter ici le code qui affiche le plateau de jeu
}






































































































/* 
const socket = new WebSocket('ws://localhost:3000'); // Connexion au serveur WebSocket

const cells = document.querySelectorAll('.cell');
const message = document.getElementById('message');
const restartButton = document.getElementById('restartButton');
const loginForm = document.getElementById('loginForm');
const usernameInput = document.getElementById('username');
const startGameButton = document.getElementById('startGame');
const scoreList = document.getElementById('scoreList');

let username = ''; // Pseudonyme du joueur
let currentPlayer = 'X';
let board = ['', '', '', '', '', '', '', '', ''];
let isGameActive = true;

// Les conditions de victoire
const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

// Envoi du pseudonyme lors du démarrage
startGameButton.addEventListener('click', (e) => {
    e.preventDefault();
    username = usernameInput.value;
    
    if (username) {
        socket.send(JSON.stringify({
            type: 'join',
            username: username
        }));

        loginForm.style.display = 'none'; // Masquer le formulaire après la connexion
    }
});

// Fonction pour vérifier si un joueur a gagné
const checkWin = () => {
    let roundWon = false;
    for (let i = 0; i < winningConditions.length; i++) {
        const winCondition = winningConditions[i];
        const a = board[winCondition[0]];
        const b = board[winCondition[1]];
        const c = board[winCondition[2]];
        if (a === '' || b === '' || c === '') {
            continue;
        }
        if (a === b && b === c) {
            roundWon = true;
            break;
        }
    }
    if (roundWon) {
        message.textContent = `Le joueur ${currentPlayer} a gagné!`;
        isGameActive = false;

        // Envoi du score au serveur
        socket.send(JSON.stringify({
            type: 'gameEnd',
            winner: username
        }));

        return;
    }

    if (!board.includes('')) {
        message.textContent = 'Match nul!';
        isGameActive = false;
        return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    message.textContent = `C'est le tour du joueur ${currentPlayer}`;
};

// Gestion du clic sur les cases
const handleCellClick = (e) => {
    const clickedCell = e.target;
    const clickedCellIndex = parseInt(clickedCell.getAttribute('data-index'));

    if (board[clickedCellIndex] !== '' || !isGameActive) {
        return;
    }

    // Mise à jour locale de l'état du jeu
    board[clickedCellIndex] = currentPlayer;
    clickedCell.textContent = currentPlayer;

    // Envoi du mouvement au serveur
    socket.send(JSON.stringify({
        type: 'move',
        player: currentPlayer,
        board: board
    }));

    checkWin();
};

// Réception des mises à jour du serveur
socket.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.type === 'move') {
        board = data.board;

        // Mettre à jour l'affichage local du plateau de jeu
        cells.forEach((cell, index) => {
            cell.textContent = board[index];
        });

        checkWin();
    }

    if (data.type === 'updateScores') {
        // Affichage des scores
        scoreList.innerHTML = ''; // Vider la liste des scores actuels
        data.scores.forEach(score => {
            const li = document.createElement('li');
            li.textContent = `${score.username}: ${score.score} points`;
            scoreList.appendChild(li);
        });
    }
};

// Pour relancer le jeu
const restartGame = () => {
    currentPlayer = 'X';
    board = ['', '', '', '', '', '', '', '', ''];
    isGameActive = true;
    message.textContent = `C'est le tour du joueur ${currentPlayer}`;
    cells.forEach(cell => cell.textContent = '');

    // Envoi de la commande de redémarrage au serveur
    socket.send(JSON.stringify({
        type: 'restart'
    }));
};

// Ajout des événements de clic sur les cases
cells.forEach(cell => cell.addEventListener('click', handleCellClick));
restartButton.addEventListener('click', restartGame);

message.textContent = `C'est le tour du joueur ${currentPlayer}`;

*/