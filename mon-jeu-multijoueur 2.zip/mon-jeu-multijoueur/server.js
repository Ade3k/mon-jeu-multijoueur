/*
const WebSocket = require('ws');
const server = new WebSocket.Server({ port: 3000 });

let activePlayers = {};  // Pour stocker les joueurs connectés et leurs scores

server.on('connection', (ws) => {
    ws.on('message', (message) => {
        const data = JSON.parse(message);
        if (data.type === 'join') {
            // Enregistrer le joueur
            activePlayers[data.username] = { score: 0, startTime: Date.now() };
            ws.send(JSON.stringify({ type: 'joinSuccess', message: `Bienvenue ${data.username}!` }));
        }

        // Autres types de messages comme 'move', 'endGame', etc.
    });

    ws.on('close', () => {
        // Gérer la déconnexion du joueur
    });
});



















// Gérer la connexion des joueurs
server.on('connection', (ws) => {
    ws.on('message', (message) => {
        const data = JSON.parse(message);

        // Quand un joueur rejoint
        if (data.type === 'join') {
            const username = data.username;

            // Enregistrer le joueur avec un score initial et l'heure de début de jeu
            if (!activePlayers[username]) {
                activePlayers[username] = { score: 0, startTime: Date.now() };
                ws.send(JSON.stringify({ type: 'joinSuccess', message: `Bienvenue ${username}!` }));
            } else {
                ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme déjà pris.' }));
            }
        }

        // Autres types de messages comme 'move', 'endGame', etc.
        if (data.type === 'move') {
            // Gérer les mouvements du jeu, mise à jour des scores...
        }

        if (data.type === 'endGame') {
            const username = data.username;
            if (activePlayers[username]) {
                const endTime = Date.now();
                const playTime = endTime - activePlayers[username].startTime;

                // Mettre à jour le score, ou faire d'autres actions
                activePlayers[username].score += 10;  // Exemple de score
                ws.send(JSON.stringify({ type: 'updateScore', score: activePlayers[username].score }));
            }
        }





        
    });

    // Gérer la déconnexion
    ws.on('close', () => {
        // Supprimer le joueur de la liste s'il se déconnecte
        // delete activePlayers[username];
    });
});


























// server.js
const WebSocket = require('ws');
const mongoose = require('mongoose');
const express = require('express');
const app = express();
const PORT = 3000;

// Connexion à MongoDB
mongoose.connect('mongodb://localhost:27017/jeu-multijoueur')
  .then(() => {
    console.log('Connecté à MongoDB');
  })
  .catch((error) => {
    console.error('Erreur de connexion à MongoDB:', error);
  });

// Schéma et modèle de joueur
const playerSchema = new mongoose.Schema({
  username: { type: String, required: true },
  avatar: { type: String, required: true },
  score: { type: Number, default: 0 }
});
const Player = mongoose.model('Player', playerSchema);

// Configurer le serveur Express et WebSocket
app.use(express.static('public')); // Pour servir les fichiers statiques

const wss = new WebSocket.Server({ server });




async function checkPlayer(username) {
    try {
        let player = await Player.findOne({ username });
        if (player) {
            console.log(`Player ${username} found`);
        } else {
            console.log(`Player ${username} not found`);
        }
    } catch (error) {
        console.error("Error checking player:", error);
    }
}






















console.log('Le serveur WebSocket est en écoute sur le port 3000');
*/





























const WebSocket = require('ws');
const mongoose = require('mongoose');
const express = require('express');
const app = express();
const PORT = 3000;

// Connexion à MongoDB
mongoose.connect('mongodb://localhost:27017/jeu-multijoueur')
  .then(() => {
    console.log('Connecté à MongoDB');
  })
  .catch((error) => {
    console.error('Erreur de connexion à MongoDB:', error);
  });


// Schéma et modèle de joueur
const playerSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  avatar: { type: String, required: true },
  score: { type: Number, default: 0 },
  playTime: { type: Number, default: 0 } // Temps de jeu en millisecondes
});

const Player = mongoose.model('Player', playerSchema);

// Stocker les joueurs actifs et le plateau du morpion
let activePlayers = {};
let morpionBoard = [['', '', ''], ['', '', ''], ['', '', '']];
let currentPlayer = null;
let movesCount = 0;

// Configurer le serveur Express pour servir les fichiers statiques (HTML, CSS, JS)
app.use(express.static('public'));

// Créer le serveur WebSocket
const server = app.listen(PORT, () => {
  console.log(`Serveur en écoute sur le port ${PORT}`);
});

const wss = new WebSocket.Server({ server });

// Gérer la connexion des joueurs
wss.on('connection', (ws) => {
  ws.on('message', async (message) => {
    const data = JSON.parse(message);

    switch (data.type) {
      // Cas 'join': Un joueur rejoint la partie avec un pseudonyme et un avatar
      case 'join':
        const { username, avatar } = data;
        if (!username || !avatar) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme et avatar requis.' }));
          return;
        }

        // Vérifier si le joueur existe déjà dans MongoDB
        let player = await Player.findOne({ username });
        if (player) {
          ws.send(JSON.stringify({ type: 'error', message: 'Pseudonyme déjà pris.' }));
        } else {
          // Créer un nouveau joueur dans la base de données
          player = new Player({ username, avatar });
          await player.save();

          // Enregistrer le joueur dans la liste active
          activePlayers[username] = { ws, score: 0, startTime: Date.now(), symbol: Object.keys(activePlayers).length === 0 ? 'X' : 'O' };
          ws.send(JSON.stringify({ type: 'joinSuccess', message: `Bienvenue ${username}!`, symbol: activePlayers[username].symbol }));

          // Choisir le joueur qui commence
          if (!currentPlayer) {
            currentPlayer = username;
            ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
          }
        }
        break;

      // Cas 'move': Gérer les déplacements dans le jeu
      case 'move':
        const { row, col } = data;
        if (activePlayers[data.username] && data.username === currentPlayer && morpionBoard[row][col] === '') {
          // Marquer le coup sur le plateau
          morpionBoard[row][col] = activePlayers[data.username].symbol;
          movesCount++;

          // Vérifier si le joueur a gagné
          if (checkWin(morpionBoard, activePlayers[data.username].symbol)) {
            activePlayers[data.username].score += 10; // Augmenter le score
            ws.send(JSON.stringify({ type: 'win', message: 'Vous avez gagné!', board: morpionBoard }));
            resetGame();
          } else if (movesCount === 9) {
            // Si tous les mouvements ont été joués et pas de gagnant, match nul
            broadcast({ type: 'draw', message: 'Match nul!', board: morpionBoard });
            resetGame();
          } else {
            // Passer au joueur suivant
            currentPlayer = getNextPlayer(data.username);
            broadcast({ type: 'boardUpdate', board: morpionBoard });
            activePlayers[currentPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
          }
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Coup invalide ou pas votre tour.' }));
        }
        break;

      // Cas 'endGame': Fin de la partie, mise à jour du score final et sauvegarde dans la base de données
      case 'endGame':
        const { username: endUsername } = data;
        if (activePlayers[endUsername]) {
          const endTime = Date.now();
          const playTime = endTime - activePlayers[endUsername].startTime;

          // Mettre à jour le score final et la durée de jeu dans MongoDB
          const playerToUpdate = await Player.findOne({ username: endUsername });
          if (playerToUpdate) {
            playerToUpdate.score = activePlayers[endUsername].score;
            playerToUpdate.playTime = playTime;
            await playerToUpdate.save();
          }

          ws.send(JSON.stringify({ type: 'updateScore', score: activePlayers[endUsername].score, playTime }));
          delete activePlayers[endUsername]; // Retirer le joueur de la liste active
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Joueur non trouvé.' }));
        }
        break;

      // Cas 'getPlayers': Consulter la liste des joueurs ayant participé au jeu, avec leur durée de jeu et score
      case 'getPlayers':
        const allPlayers = await Player.find({}, { username: 1, score: 1, playTime: 1, _id: 0 }); // Obtenir uniquement les informations nécessaires
        ws.send(JSON.stringify({ type: 'playersList', players: allPlayers }));
        break;

      // Cas 'restart': Redémarrer la partie
      case 'restart':
        resetGame();
        broadcast({ type: 'gameRestarted', message: 'La partie a été redémarrée.', board: morpionBoard });
        currentPlayer = Object.keys(activePlayers)[0];
        activePlayers[currentPlayer].ws.send(JSON.stringify({ type: 'yourTurn', message: 'C\'est ton tour!', board: morpionBoard }));
        break;

      default:
        ws.send(JSON.stringify({ type: 'error', message: 'Type de message non reconnu.' }));
        break;
    }
  });

  // Gérer la déconnexion des joueurs
  ws.on('close', () => {
    for (const username in activePlayers) {
      if (activePlayers[username].ws === ws) {
        delete activePlayers[username];
        console.log(`Joueur ${username} déconnecté`);
      }
    }
  });
});

console.log('Le serveur WebSocket est en écoute sur le port 3000');

// Fonction pour vérifier si un joueur a gagné
function checkWin(board, symbol) {
  // Vérifier les lignes, colonnes et diagonales
  for (let i = 0; i < 3; i++) {
    if (board[i][0] === symbol && board[i][1] === symbol && board[i][2] === symbol) return true;
    if (board[0][i] === symbol && board[1][i] === symbol && board[2][i] === symbol) return true;
  }
  if (board[0][0] === symbol && board[1][1] === symbol && board[2][2] === symbol) return true;
  if (board[0][2] === symbol && board[1][1] === symbol && board[2][0] === symbol) return true;

  return false;
}

// Fonction pour redémarrer le jeu
function resetGame() {
  morpionBoard = [['', '', ''], ['', '', ''], ['', '', '']];
  currentPlayer = null;
  movesCount = 0;
}

// Fonction pour passer au joueur suivant
function getNextPlayer(currentUsername) {
  const players = Object.keys(activePlayers);
  const currentIndex = players.indexOf(currentUsername);
  return players[(currentIndex + 1) % players.length];
}

// Fonction pour envoyer un message à tous les joueurs
function broadcast(message) {
  Object.values(activePlayers).forEach(player => {
    player.ws.send(JSON.stringify(message));
  });
}

